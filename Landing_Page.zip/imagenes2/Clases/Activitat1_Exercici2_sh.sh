#!/bin/bash

echo"Script para crear de carpetas"

# creacion de carpetas
mkdir /dev/sdc1/arkano
mkdir /dev/sdc1/luis/arkano
mkdir /dev/sdc1/arkano/arkano-1
mkdir /dev/sdc1/arkano/arkano-2
mkdir /dev/sdc1/arkano/arkano-3
mkdir /dev/sdc1/arkano/arkano-4
mkdir /dev/sdc1/arkano/arkano-5
mkdir /dev/sdc1/arkano/arkano-6
mkdir /dev/sdc1/arkano/arkano-7
mkdir /dev/sdc1/arkano/arkano-8
mkdir /luis/arkano/Compartido1
mkdir /luis/arkano/Compartido2

tree /arkano
tree /luis/arkano