list=['lunes', 'martes', 'miercoles']
print(list, [3])