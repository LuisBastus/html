#!/usr/bin/env python3

print("##########")
print("Exercici 1")
print("##########")

l = list(range(1))
print(l)

l = list(range(3))
print(l)

l = list(range(0))
print(l)

l = list(range(100, 104))
print(l)

l = list(range(100, 6101, 1000))
print(l)

l = list(range(10, 8011, 2000))
print(l)

l = list(range(5, -196, -50))
print(l)

l = list(range(10, -391, -100))
print(l)








