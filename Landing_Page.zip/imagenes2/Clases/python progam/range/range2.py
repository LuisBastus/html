numero= input("escribe un numero entero")
