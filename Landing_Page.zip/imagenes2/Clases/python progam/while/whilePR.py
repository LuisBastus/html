num = int(input("Escribe un numero: "))

while num > 100:
    int(input("escribe otro numero: "))
 
if num < 100:
    print("fin del programa")